""" This folder is copied over from references/detection under the torchvision
repo: https://github.com/pytorch/vision
"""
