# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License.

__title__ = "Microsoft Computer Vision"
__version__ = "2019.08"
__author__ = "CVDev Team at Microsoft"
__license__ = "MIT"
__copyright__ = "Copyright 2018-present Microsoft Corporation"
